variable "allocated_storage" {
  description = "amount of storage"
  default     = 50
}
variable "ca_cert_identifier" {
  description = "Identifier of the CA certificate for the DB instance."
}
variable "db_name" {
  description = "database name"
}
variable "db_subnet_group_name" {
  description = "Name of the DB Subnet Group"
  
}
variable "environ" {
  description = "The environment you want to use"
}
variable "environment_long" {
  description = "The long name of the environment you want to use"
}
variable "identifier" {
  description = "The RDS database identifier"
}
variable "monitoring_interval" {
  description = "The interval, in seconds, between points when Enhanced Monitoring metrics are collected for the DB instance. To disable collecting Enhanced Monitoring metrics, specify 0. The default is 0. Valid Values: 0, 1, 5, 10, 15, 30, 60."
  default     = 0
}
variable "monitoring_role_arn" {
  description = "The role that will be used to as permission to send logs to aws_cloudwatch"
  default     = ""
}
variable "parameter_group_name" {
  description = "parameter group name"
}
variable "performance_insights_enabled" {
  description = "Specifies whether Performance Insights are enabled. Defaults to false."
  default     = false
}
variable "region" {
  description = "AWS region"
}
variable "security_group_ids" {
  type        = list(any)
  description = "List of SecurityGroup IDs to use for the RDS instance"
}
variable "snapshot_identifier" {
  description = "Snapshot to create backup from"
  default     = null
}

variable "storagetype" {
  description = "Type of Storage GP2/GP3"
  default     = "gp3"
}

variable "max_allocated_storage" {
  description = "The upper limit to which Amazon RDS can automatically scale the storage of the DB instance"
  default     = null
}

variable "backup_retention_period" {
  description = "Number of days to keep backups (must be between 0 and 35)"
  default     = 35
}

variable "backup_window" {
  description = "The daily time range (in UTC) during which automated backups are created"
  default     = "09:00-09:30"
}

variable "db_password" {
  description = "Default password (THIS MUST BE CHANGED AFTER THE INSTANCE IS AVAILABLE)"
  default     = "ZPHwDMafPne0"
}

variable "db_version" {
  description = "database version"
  default     = "16.3"
}

variable "db_username" {
  description = "Default username"
  default     = "db_master"
}

variable "deletion_protection" {
  description = "Is the database protected against deletion?"
  default     = true
}

variable "enabled_cloudwatch_logs_exports" {
  description = "List of log types to enable for exporting to CloudWatch"
  default     = ["postgresql"]
}

variable "instance_class" {
  description = "instance size and class"
  default     = "db.t2.medium"
}

variable "kms_key_id" {
  description = "kms_key_id"
  default     = ""
}

variable "maintenance_window" {
  description = "The daily time range (in UTC) during which upgrades/maintenance occur"
  default     = "sun:10:00-sun:10:30"
}

variable "multi_az" {
  description = "Is the instance Multi-AZ?"
  default     = false
}

variable "option_group_name" {
  description = "Option group name for the RDS instance"
  default     = "default:postgres-17"
}

variable "replica_source_db" {
  description = "replica_sourece_db"
  default     = null
}

variable "skip_final_snapshot" {
  description = "Should the final snapshot be skipped"
  default     = false
}

variable "storage_encrypted" {
  description = "Is the DB encrypted at rest"
  default     = true
}

variable "apply_immediately" {
  description = "Specifies whether any database modifications are applied immediately, or during the next maintenance window, Can Cause downtime"
  default     = false
}

variable "delete_automated_backups" {
  description = "Specifies whether to remove automated backups immediately after the DB instance is deleted"
  default     = false
}



###### https://docs.gitlab.com/ee/user/infrastructure/iac/terraform_state.html