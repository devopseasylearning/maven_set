# Create IAM Role for RDS Monitoring
resource "aws_iam_role" "rds_full_access_role" {
  name               = "RDSFullAccessRole"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = {
          Service = "monitoring.rds.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })
}

# Attach Managed Policy for RDS Full Access
resource "aws_iam_role_policy_attachment" "rds_full_access_policy" {
  role       = aws_iam_role.rds_full_access_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSFullAccess"
}

