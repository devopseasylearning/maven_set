variable "database_name" {
  description = "The name of the database"
  type        = string
  default     = "exampledb" # Provide a default value or leave it out if mandatory
}

variable "aws_region" {
  description = "The AWS region to deploy resources"
  type        = string
  default     = "us-east-1" # Replace with your desired region
}

variable "environ" {
  description = "Environment (e.g., dev, staging, prod)"
  type        = string
}

variable "environment_long" {
  description = "Long form of environment"
  type        = string
}

variable "securitygroup_database" {
  description = "Security group ID for the database nodes"
  type        = string
}

variable "database_subnet_group" {
  description = "Database subnet group name"
  type        = string
}


# Variable for Subnet IDs
variable "subnet_ids" {
  description = "List of subnet IDs for the DB subnet group"
  type        = list(string)
  default     = [
    "subnet-xxxxxxx", # Default subnet in us-east-1c
    "subnet-xxxxxxx"  # Default subnet in us-east-1b
  ]
}

# Variable for Subnet Group Name
variable "db_subnet_group_name" {
  description = "The name of the DB subnet group"
  type        = string
  default     = "main"
}

# Variable for Tags
variable "db_subnet_group_tags" {
  description = "Tags for the DB subnet group"
  type        = map(string)
  default = {
    Name = "My DB subnet group"
  }
}

# Variable for gitlab-token
variable "gitlab_token" {
  description = "Tags for the DB subnet group"
  type        = string
  }
}

