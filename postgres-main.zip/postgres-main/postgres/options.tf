# Create RDS Parameter Group for PostgreSQL 16
resource "aws_db_parameter_group" "postgres16_prod_sec" {
  name        = "postgres16-prod-sec"
  family      = "postgres16"
  description = "Custom parameter group for PostgreSQL 16 - production secure"

  parameter {
    name         = "max_connections"
    value        = "200"
    apply_method = "pending-reboot"
  }

  parameter {
    name         = "log_min_duration_statement"
    value        = "1000" # Log queries longer than 1 second
    apply_method = "immediate"
  }
}

# Create RDS Option Group for PostgreSQL 16
resource "aws_db_option_group" "postgres16_option_group" {
  name                 = "postgres16-option-group"
  engine_name          = "postgres"
  major_engine_version = "16"
}
