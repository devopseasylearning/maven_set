terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0" # Use the latest version compatible with 5.x
    }
    
  }

  required_version = ">= 1.5.0" # Ensure Terraform version compatibility
}

provider "aws" {
  region = "var.aws_region"

}




