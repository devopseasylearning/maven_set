module "abc-abc-database" {
  source  = "git::git@gitlab.com:devopseasylearning/postgres.git?ref=v1.0.0"


  environ                  = var.environ
  environment_long         = var.environment_long
  instance_class           = "db.t4g.xlarge"
  storage_encrypted        = true
  region                   = var.aws_region
  parameter_group_name     = aws_db_parameter_group.postgres16_prod_sec.name
  option_group_name        = aws_db_option_group.postgres16_option_group.name
  db_version               = "16.3"
  identifier               = replace(lower(var.database_name), "_", "-")
  db_name                  = var.database_name
  deletion_protection      = true
  multi_az                 = true
  security_group_ids       = [var.securitygroup_database]
  db_subnet_group_name     = var.database_subnet_group
  ca_cert_identifier       = "rds-ca-rsa2048-g1"
  monitoring_interval      = "60"
  monitoring_role_arn      = aws_iam_role.rds_full_access_role.arn
  performance_insights_enabled = true
  allocated_storage        = 30
  max_allocated_storage    = 60
  apply_immediately        = true
  skip_final_snapshot      = false
  backup_retention_period  = 35
}

# resource "aws_db_subnet_group" "default" {
#   name       = var.db_subnet_group_name
#   subnet_ids = var.subnet_ids

#   tags = var.db_subnet_group_tags
# }
