resource "aws_db_instance" "abc-abc_postgres_db" {
  # These attribtes are currently hard-coded
  allow_major_version_upgrade = "true"
  # Don't set engine if database is a replica
  engine                    = var.replica_source_db == null ? "postgres" : null
  final_snapshot_identifier = var.skip_final_snapshot == false ? "${replace(lower(var.identifier), "_", "-")}-final-snapshot" : null

  # These attributes can be passed in via variables
  allocated_storage               = var.allocated_storage
  backup_retention_period         = var.backup_retention_period
  backup_window                   = var.backup_window
  ca_cert_identifier              = var.ca_cert_identifier
  db_name                         = var.db_name
  db_subnet_group_name            = var.db_subnet_group_name
  delete_automated_backups        = var.delete_automated_backups
  deletion_protection             = var.deletion_protection
  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports
  engine_version                  = var.db_version
  identifier                      = replace(lower(var.identifier), "_", "-")
  instance_class                  = var.instance_class
  maintenance_window              = var.maintenance_window
  max_allocated_storage           = var.max_allocated_storage
  monitoring_interval             = var.monitoring_interval
  monitoring_role_arn             =  var.monitoring_role_arn
  multi_az                        = var.multi_az
  option_group_name               = var.option_group_name
  parameter_group_name            = var.parameter_group_name
  password                        = var.db_password
  performance_insights_enabled    = var.performance_insights_enabled
  skip_final_snapshot             = var.skip_final_snapshot
  storage_encrypted               = var.storage_encrypted
  storage_type                    = var.storagetype
  username                        = var.db_username
  vpc_security_group_ids          = var.security_group_ids


  # Use to restore from snapshot
  snapshot_identifier = var.snapshot_identifier


  # Use if setting up a Read Replica
  replicate_source_db = var.replica_source_db
  kms_key_id          = var.kms_key_id
  apply_immediately   = var.apply_immediately

  timeouts {
    create = "90m"
    delete = "2h"
  }

  tags = {
    Name             = var.identifier
    Environment      = var.environ
    Environment_Long = var.environment_long
  }
}
