# abc-abc Database

After creating an RDS database, we need to change the master password, then
create a user that the apps will use.

### Change master user password

```sql
ALTER ROLE abc-abc_master WITH PASSWORD '__NEW_PASSWORD__';
```

### Setup app user
```sql
CREATE USER "<USER>" WITH LOGIN NOSUPERUSER INHERIT CREATEDB NOCREATEROLE NOREPLICATION PASSWORD '<PASSWORD>';
GRANT "<USER>" TO abc-abc_master;
CREATE DATABASE "zuul_demo" WITH OWNER = "zuul" ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8' CONNECTION LIMIT = -1;
```
